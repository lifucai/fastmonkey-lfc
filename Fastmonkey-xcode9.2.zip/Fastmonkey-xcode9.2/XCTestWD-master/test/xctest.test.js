'use strict';

require('should');

var XCTest = require('..');

describe('test', function() {
  it('should be ok', function() {
    XCTest.should.be.ok();
  });
});
