//
//  XCTestWDApplication.h
//  XCTestWDUITests
//
//

#import <Foundation/Foundation.h>
#import "XCUIApplication.h"

@interface XCTestWDApplication: NSObject

+(XCUIApplication*)activeApplication;

@end
