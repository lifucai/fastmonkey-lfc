'use strict';

module.exports = require('./lib/xctest-client');
