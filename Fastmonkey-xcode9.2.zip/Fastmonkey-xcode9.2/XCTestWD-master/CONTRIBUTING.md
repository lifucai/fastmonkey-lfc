# Contributing to XCTestWD

We love pull requests from everyone.

## Link Global To Local

``` bash
$ cd path/to/macaca-ios
$ npm link path/to/XCTestWD
# now project XCTestWD is linked to macaca-ios
```

## Run with XCode

``` bash
$ open ./XCTestWD/XCTestWD.xcodeproj
# run test(command + u) in XCTestWDUITests schema
# ./XCTestWD/curlTests.sh is some useful restful testing scripts
```
